package com.javatpoint.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;
import com.javatpoint.repository.PassengerRepository;

@Service
public class PassengerService
{
	@Autowired
	PassengerRepository passengerRepository;
	
	//Getting all records
	public List<Passenger> getAllPassenger()
	{
		List<Passenger>passenger=new ArrayList<Passenger>();
		passengerRepository.findAll().forEach(passengers -> passenger.add(passengers));
		return passenger;
		
	}
	
	//Getting single record
	public Passenger getPassengerById(Integer id)
	{
		return passengerRepository.findById(id).get();	
	}
	//Saving record
	public String saveOrUpdate(Passenger p)
	{
//		Ticket ticket=passengerRepository.FindTicket(p.getTicket().getTicketId(),p.getTicket().getArrivalDate(),p.getTicket().getDestination());
//		if(ticket==null)
//			{
//				passengerRepository.save(p);
//				return "sucessfully done";
//						}
//			else
//			{
//				return "already have ticket book";
//				}
		
		
		Ticket ticket=passengerRepository.FindTicket(p.getTicket().getTicketId());
		if(ticket==null)
		{
			passengerRepository.save(p);
			
			 return "yes";
		
	}
		else
		{
			return "no";
			
			}
		
	}
	
	public void delete(Integer id)
	{
		passengerRepository.deleteById(id);
	}
	

}
