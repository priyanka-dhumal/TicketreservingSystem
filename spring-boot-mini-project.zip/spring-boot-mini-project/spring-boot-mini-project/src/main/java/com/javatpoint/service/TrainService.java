package com.javatpoint.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Ticket;
import com.javatpoint.model.Train;
import com.javatpoint.repository.TicketRepository;
import com.javatpoint.repository.TrainRepository;
@Service
public class TrainService {
	@Autowired
	TrainRepository trainRepository;
	public List<Train> getAllTickets(){
		List<Train> train =new ArrayList<Train>();
		trainRepository.findAll().forEach(Train -> train.add(Train));
		return train;
	}
	public Train getById(Integer id)
	{
		return trainRepository.findById(id).get();
	}
	public void saveOrUpdate(Train train)
	{
		trainRepository.save(train);
	}
	public void delete(Integer id)
	{
		trainRepository.deleteById(id);
	}
	

}
