package com.javatpoint.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;
import com.javatpoint.model.Train;
import com.javatpoint.service.TrainService;

@RestController
public class TrainContrtoller {
	@Autowired
	TrainService trainService;
	@GetMapping("/trains")
	private List<Train> getAllTickets()
	{
		return trainService.getAllTickets();
	}
	@GetMapping("/trains/{trainId}")
	private Train getTrain(@PathVariable ("trainId") Integer trainId)
	{
		return trainService.getById(trainId);
	}
	
	@DeleteMapping("/trains/{trainId}")
	private void deleteTrain(@PathVariable("trainId") Integer trainId) 
	{
	trainService.delete(trainId);
	}
	
	//creating post mapping 
	@PostMapping("/trains")
	private int saveBook(@RequestBody Train train) 
	{
	trainService.saveOrUpdate(train);
	return train.getTrainId();
	}
	//creating put mapping that updates detail 
	@PutMapping("/trains")
	private Train update(@RequestBody Train train) 
	{
	trainService.saveOrUpdate(train);
	return train;
	}

}
