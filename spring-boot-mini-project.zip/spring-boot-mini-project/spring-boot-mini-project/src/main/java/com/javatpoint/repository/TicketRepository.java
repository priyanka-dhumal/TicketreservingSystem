package com.javatpoint.repository;

import org.springframework.data.repository.CrudRepository;

import com.javatpoint.model.Ticket;

public interface TicketRepository extends CrudRepository<Ticket, Integer> 
{
	


}
