package com.javatpoint.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Ticket;
import com.javatpoint.repository.TicketRepository;

@Service
public class TicketService 
{
	@Autowired
	TicketRepository ticketRepository;
	public List<Ticket> getAllTickets(){
		List<Ticket> ticket =new ArrayList<Ticket>();
		ticketRepository.findAll().forEach(Ticket1 -> ticket.add(Ticket1));
		return ticket;
	}
	
	public List<Ticket> getAllTicket()
	{
		List<Ticket> ticket=new ArrayList<Ticket>();
		ticketRepository.findAll().forEach(ticket1 -> ticket.add(ticket1));
		return ticket;
	}
	
	public Ticket getById(Integer id)
	{
		return ticketRepository.findById(id).get();
	}
	public void saveOrUpdate(Ticket ticket)
	{
		ticketRepository.save(ticket);
	}
	public void delete(Integer id)
	{
		ticketRepository.deleteById(id);
	}

}
